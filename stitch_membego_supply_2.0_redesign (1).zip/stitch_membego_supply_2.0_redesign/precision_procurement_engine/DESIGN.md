---
name: Precision Procurement Engine
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#824500'
  on-tertiary: '#ffffff'
  tertiary-container: '#a65900'
  on-tertiary-container: '#ffede1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.005em
  metric-display:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.025em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-dense:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.25rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system embodies high-frequency operational clarity, financial precision, and institutional trust. Built for enterprise supply chain controllers, finance directors, and procurement leads, the visual language balances high-density data management with refined, modern SaaS elegance. 

The aesthetic is anchored in **Corporate / Modern High-Density Minimalism**, drawing direct influence from modern productivity powerhouses and modern fintech infrastructure:
- **Structural Precision:** Crisp 1px boundaries, balanced horizontal divisions, and strict alignments eliminate visual noise, allowing operators to scan large volumes of procurement requisitions and ledgers effortlessly.
- **Controlled Density:** Generous legibility within compact footprints; vertical height is engineered for maximum on-screen situational awareness without sacrificing hierarchy.
- **Institutional Authority:** Deep electric blues establish trust and velocity, while meticulous slate tones provide an optical hierarchy where critical financial signals stand out immediately.

## Colors

The palette balances cool, non-distracting canvas layers against high-contrast interactive states and precise semantic signals:

### Core Hierarchy
- **Canvas & Backing Surfaces:** Cool Slate Off-White (`#F8FAFC` base page background, `#F1F5F9` nested canvas/inset wells).
- **Surface Elevation:** Pure White (`#FFFFFF`) for cards, sheets, tables, and modal layers, bound by a razor-thin structural border (`#E2E8F0`).
- **Primary Interactive:** Deep Electric Blue (`#2563EB` default, `#1D4ED8` hover/active, `#EFF6FF` subtle interactive container).

### Text & Visual Weights
- **Primary Headings & Key Metrics:** Slate 900 (`#0F172A`) for absolute contrast and legibility.
- **Body & Primary Labels:** Slate 600 (`#475569`) providing a balanced optical cadence.
- **Secondary & Muted Data:** Slate 400 (`#94A3B8`) for table column descriptors, timestamps, and input placeholding.

### Functional & Financial Semantics
- **Positive / Cleared / Active:** Emerald (`#059669` foreground text and icons, paired with `#ECFDF5` container/fill).
- **Pending / In Review / Discrepancy:** Amber (`#D97706` text/icons, `#FEF3C7` container).
- **Critical / Rejected / Incident:** Crimson (`#DC2626` text/icons, `#FEF2F2` container).
- **Draft / Inactive / Closed:** Slate (`#64748B` text/icons, `#F1F5F9` container).

## Typography

Typography centers exclusively on **Inter** to ensure maximum legibility, balanced geometry, and unified cross-platform rendering across high-density layouts.

### Tabular Numerics & Financial Figures
- All monetary currencies (such as `RD$`, `USD`, `EUR`), balance ledgers, inventory counts, and timestamp tables must explicitly enable OpenType tabular numbers via `font-feature-settings: "tnum" 1`. This aligns decimals and integer places vertically across table rows.
- Table headers utilize `label-sm` with uppercase transformation and a subtle letter-spacing adjustment (`+0.04em`) to establish visual separation from cell values.
- Monospaced identifiers (SKUs, hash digests, batch numbers) default to **JetBrains Mono** via the `code-dense` scale.

## Layout & Spacing

The layout uses a **fluid-responsive layout system** balanced by strict column rules and max-width containers for wide dashboards:

### Layout Rhythm
- **Base Grid:** Built on an 8px architectural grid with a 4px half-step for micro-elements (table row paddings, tag insets, segmented controls).
- **Desktop (1280px+):** Fluid sidebar configuration (collapsed: 64px, expanded: 240px) with a 12-column adaptive sub-grid, `gutter-lg` (24px), and `margin-lg` (32px).
- **Tablet (768px - 1279px):** 8-column layout, `gutter-md` (20px), and `margin-md` (24px). Sidebar collapses to persistent rail navigation.
- **Mobile (<768px):** 4-column layout, `gutter` (16px), and `margin` (16px). Data tables collapse into keyed card lists.

## Elevation & Depth

This system avoids heavy drop shadows, opting instead for **tactile borders and low-contrast surface stratification**:

1. **Flat Base Layers:** Canvas (`#F8FAFC`) to Card (`#FFFFFF`) relies on a 1px solid `#E2E8F0` border. Shadows are completely omitted on standard grid surfaces.
2. **Interactive Subtle Lift:** Interactive list items or clickable cards receive a micro-shadow on hover: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`.
3. **Dropdowns & Popovers:** `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)` combined with an `#E2E8F0` hairline boundary.
4. **Modals & Flyouts:** `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)` with a backdrop blur overlay (`rgba(15, 23, 42, 0.4)`).

## Shapes

The interface embraces a **Soft / Crisp Structural** philosophy (`roundedness: 1`):

- **Default Elements:** 4px (`rounded`, 0.25rem) for form inputs, table actions, micro status badges, and inline buttons.
- **Structural Containers:** 6px–8px (`rounded-md` to `rounded-lg`) for cards, KPI panels, sub-navigation groupings, and flyout sheets.
- **Pill Badges & Indicator Dots:** 9999px fully-rounded pills are reserved exclusively for status chips, micro-progress fills, and numerical avatar counts.

## Components

### Buttons
- **Primary:** Background `#2563EB`, text `#FFFFFF`, 1px border `transparent`, subtle inset top highlight `inset 0 1px 0 rgba(255, 255, 255, 0.15)`. Active state shifts to `#1D4ED8`. Height: 32px (compact), 36px (regular).
- **Secondary / Outline:** Background `#FFFFFF`, text `#0F172A`, 1px border `#E2E8F0`. Hover: `#F8FAFC` background with `#CBD5E1` border.
- **Ghost:** Transparent background, text `#475569`. Hover: `#F1F5F9`.

### Data Tables (High Density)
- **Header:** Height 36px, background `#F8FAFC`, bottom border 1px solid `#E2E8F0`, typography `label-sm` with `#64748B`.
- **Row:** Height 44px, background `#FFFFFF`, bottom border 1px solid `#F1F5F9`. Hover state shifts background to `#F8FAFC`.
- **Numeric Alignment:** All currency, quantity, and metric columns are right-aligned with `tnum` font features.

### Unified Status Chips
- Pill geometry with padding `2px 8px`, typography `label-sm` (11px, 600 weight).
- **Composition:** 6px solid colored circular dot on the left followed by the status label:
  - *Active / Received:* Green dot (`#059669`), green text (`#059669`), light green background (`#ECFDF5`).
  - *Pending / In Review:* Amber dot (`#D97706`), amber text (`#D97706`), light amber background (`#FEF3C7`).
  - *Cancelled / Alert:* Crimson dot (`#DC2626`), crimson text (`#DC2626`), light red background (`#FEF2F2`).
  - *Draft / Idle:* Slate dot (`#64748B`), slate text (`#64748B`), slate background (`#F1F5F9`).

### KPI Metric Cards
- Background `#FFFFFF`, 1px solid `#E2E8F0`, padding `16px`.
- Structure: Micro header row with uppercase category title (`label-sm`, `#64748B`) and tertiary action/info icon. Main value displayed in `metric-display` (`#0F172A`). 
- Footer displays inline comparison badge (e.g., `+12.4% vs last mo`) with micro upward/downward arrow in emerald or crimson.

### Micro Progress Bars
- Height 4px or 6px, background `#E2E8F0`, fully rounded pill track. Indicator fill defaults to `#2563EB` for neutral progression, switching dynamically to `#059669` upon 100% fulfillment.

### Input Fields & Controls
- Height 36px, background `#FFFFFF`, border 1px solid `#CBD5E1`, typography `body-md`. Focus rings use `box-shadow: 0 0 0 2px #EFF6FF, 0 0 0 3px #2563EB`.
- Checkboxes: 16x16px, 3px border radius, `#2563EB` checked fill with crisp white checkmark icon.